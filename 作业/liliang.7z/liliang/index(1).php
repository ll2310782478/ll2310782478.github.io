<?php session_start();   //启用session  ?>
<!DOCTYPE html>
<html>
	<head>
		<meta charset="UTF-8">
		<title>网站模板</title>
		<style>
			.container{
			width:1000px;
			height:auto;
			border: 2px solid black;
			margin:0 auto;	
			}
			.header{width:980px;
			height:100px;
			border: 2px solid black;
			background: green;	
			}
			.nav{width:980px;
			height:40px;
			border: 2px solid red;
			text-align: center;	
			}
			.nav a{
			text-decoration: none;	
			color:#333;
			/*border:2px solid red;*/
			line-height:40px ;
			margin-left:10px;
			}
			.nav a:hover{
				color:red;
			}
			
			.main{width:980px;
			height:560px;
			/*border: 2px solid black;*/
			/*overflow: hidden;	*/
			}
			.footer{width:980px;
			height:100px;
			border: 2px solid black;
			background: green;
			text-align: center;	
			}
			.main_left{
				width:200px;
				height: 330px;
				border:3px solid  red;
				float:left;
			}
			.main_middle{
				width:560px;
				height: 330px;
				border:3px solid  blue;
				float:left;
			}
			.main_right{
				width:200px;
				height: 330px;
				border:3px solid  green;
				float:left;
			}
			.clear{
				clear: both;
			}
			.footer p{
				color:white;
				font-size: 16px;
			}
			.t1{ text-align:center;}
			
		</style>
	</head>
	<body>
		<div class="container">
			<div class="header">
				<a href="index.html"><img src="img/logo.png"></a>
				<img src="img/banner.png">
				<form method="get" action="">
					关键字：<input type="text" name="keyword">
					<input type="submit" name="search" value="查找">
				</form>	
			</div>
			
			<div class="nav">
				<nav>
				<?php
				  if(!isset($_SESSION["uname"])){  //若用户没有登陆
					echo "<a href=login.html>[请登录</a>";
					echo "<a href=register.html>,注册]</a>";
					}else{   //用户已经登录了
					echo "<a href=#>[".$_SESSION["uname"]."</a>" ;
					if($_SESSION["flag"]==1){
					 echo "<a href=admin/index.php>,后台商品管理</a>";	
					}
					echo "<a href=user.php>,用户中心 ";
					echo "<a href=look.php>,购物车 ";
					echo "<a href=quit.php>,安全退出 ]</a>";
					}
				?>	
					<a href="index.html">首页</a>
					<a href="shanshu.html">秦岭山水</a>
					<a href="meishi.html">秦岭美食</a>
					<a href="jingdian.html">旅游景点</a>
					<a href="fupin.html">扶贫故事</a>										
				</nav>
			</div> <!--end of nav -->
			
			
			
			<div class="main">
				<div class="main_left">left</div>
				<div class="main_middle">
				 <?php
				   //思路： 从sp数据表中读取商品数据，并显示
				 	
//连接到数据库
	$conn=mysqli_connect("localhost","root","");
	if(!$conn){ echo "连接数据库服务器出错了！"; exit;}
// 打开指定的数据库
	mysqli_select_db($conn,"liliang") or die("打开数据库出错了！"); 
	mysqli_query($conn,"set names utf8");  //防止汉字乱码
	
	//构造动态查询
	if(isset($_GET["search"]) && !empty($_GET["keyword"]))
	{
		$keyword=$_GET["keyword"];
	    $sql="select * from sp where spname like '%$keyword%'";
	}else{
    $sql="select * from sp";
    }
    
    
    $result=mysqli_query($conn,$sql);
    if(mysqli_num_rows($result)>0){
       //echo "商品信息表如下：";
       //输出sp表中的数据
        echo "<table border='0' width='100%' class=t1>";	
        	$i=0;  //控制换行，每行输出3个商品图片
        	echo "<tr>";  	
        while($cur_sp=mysqli_fetch_row($result))
		 { 
		 echo "<td>";
		// echo "<img width=180 height=180 src=img/".$cur_sp[4].">.<br>";
		 echo "<a href='detail.php?spid=$cur_sp[0]&spname=$cur_sp[1]&price=$cur_sp[2]&jianjie=$cur_sp[3]&shuliang=9&picture=$cur_sp[4]&haoping=$cur_sp[5]&buyflag=1'>
	<img src='./img/$cur_sp[4]' width='180' height='180'></a> 
    <br>";		
		 	
		 	
		 	
		 echo "￥". $cur_sp[2]."元 <br>	";	
		 echo $cur_sp[1];
		 echo "</td>";

		 $i++;
		 if($i%3==0)  {echo "</tr>";   echo "<tr>";}
			}
		echo "</tr>";		
       echo "</table>";
    }else{
    	echo "没有商品";
    }		   
				 ?>
			</div><!-- end of main_middle-->

				<div class="main_right">right</div>
				<div class="clear"></div>
			</div> <!-- end of main -->
			
			
			
			
			<div class="footer">
				<p>友情链接：西航</p>
				<p>版权所有：21040051-52</p>
			</div>
		</div>
	</body>
</html>
